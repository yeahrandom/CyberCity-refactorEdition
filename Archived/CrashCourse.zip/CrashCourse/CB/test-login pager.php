
<!--

<?php include "template.php"; ?>
<title>Cyber City - registration</title>

<h1 class='text-primary'>please register for our sight</h1>
<! --
create bootstrap form for 2 fields

-user
-pass
data need cloceted and stored user databace acess level 1
IMPORTANT - password be hashed prior ro save databace
-->

<div>
    <div style="margin-top:20px">
        <div>
            <form name="form_login" method="post" action="login.php" role="form">
                <fieldset>
                    <h2>Please Sign In</h2>
                    <hr>
                    <div>
                        <input name="user_id" type="text" id="user_id" placeholder="Email Address">
                    </div>
                    <div>
                        <input type="password" name="password" id="password" placeholder="Password">
                    </div>
                    <span>
          <button type="button" data-color="info">Remember Me</button><!-- Additional Option -->
          <input type="checkbox" name="remember_me" id="remember_me" checked="checked">
          <hr>
          <div>
            <div>
              <input type="submit" name="Submit" value="Login">
            </div>
            <div> <a href="http://creativealive.com/basic-registration-form-php-mysql-database-connectivity/" target="_blank">Register<small>- Read Article</small></a> </div>
          </div>
                </fieldset>
            </form>
        </div>
    </div>
</div>


-->