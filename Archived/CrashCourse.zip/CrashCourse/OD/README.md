# OD - PHP practice 

This is a folder for OD's PHP test enviroment 

OD