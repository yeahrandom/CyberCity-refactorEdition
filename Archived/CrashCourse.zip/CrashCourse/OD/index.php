
<?php include "template.php"; ?>
<title>Cyber City</title>

<h1 class='text-primary'>Welcome to the Cyber City</h1>
