// Replace with your network credentials
const char* ssid     = "RoboRange";
const char* password = "Password01";

// REPLACE with your Domain name and URL path or IP address with path
const char* serverName = "http://192.168.1.8/CyberCity/CrashCourse/RC/post-esp-data.php";

// Keep this API Key value to be compatible with the PHP code provided in the project page.
// If you change the apiKeyValue value, the PHP file /post-esp-data.php also needs to have the same key
String apiKeyValue = "tPmAT5Ab3j7F9";

String sensorName = "Tempature";
String sensorLocation = "Dylan";
