<?php include "template.php"; ?>
<title>Cyber City</title>

<h1 class='text-primary'>Welcome to our Cyber City</h1>
</body>
</html>